﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinPelota
{
    public partial class FormWinPelota : Form
    {
        private bool bd;
        private Pelota pelota;

        public FormWinPelota()
        {
            InitializeComponent();
            pelota = new Pelota(PBCancha.Width, PBCancha.Height);
            bd = false;

        }

        private void BotonSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BotonComenzar_Click(object sender, EventArgs e)
        {
            if(bd == true)
            {
                bd = false;
                BotonComenzar.Text = "Comenzar";
            }
            else 
            { 
                bd = true;
                BotonComenzar.Text = "Pausar";
            }
            pelota.Mostrar();

            /*if (pelota.GetEstado())
            {
                //Estado = visible
                pelota.Borrar(PBCancha.CreateGraphics());
            }
            else
            {
                //Estado = invisible
                pelota.Dibujar(PBCancha.CreateGraphics());

            }
            pelota.CambiaEstado();*/

            /*pelota.Borrar(PBCancha.CreateGraphics());
            pelota.Mover();
            pelota.Dibujar(PBCancha.CreateGraphics());*/
            
        }



        private void Timer_Tick(object sender, EventArgs e)
        {
            //pelota.Borrar(PBCancha.CreateGraphics());
            if (bd == true)
            {
                pelota.Mover(trackBar.Value);
                PBCancha.Invalidate();
            }

            
        }

        private void PBCancha_Paint(object sender, PaintEventArgs e)
        {
            pelota.Dibujar(e.Graphics);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar_Scroll(object sender, EventArgs e)
        {
            Console.WriteLine("Valor de trackbar: " + trackBar.Value);
        }
    }
}
