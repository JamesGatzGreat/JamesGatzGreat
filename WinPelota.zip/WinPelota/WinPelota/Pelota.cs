﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinPelota
{
    class Pelota
    {
        private int radio;
        private double x;
        private double y;
        private int sentidox;
        private int sentidoy;
        private int angulo;
        private double anguloRad;
        private bool visible;

        private double ancho;
        private double alto;
        private double velo;

        public Pelota(double ancho, double alto)
        {
            radio = 20;
            x = 20;
            y = 20;
            sentidox = 1;
            sentidoy = 1;
            angulo = 35;
            anguloRad = angulo * Math.PI / 180.0;
            visible = false;
            this.ancho = ancho;
            this.alto = alto;

        }
        public void Mostrar()
        {
            Console.WriteLine("({0} , {1}) - r: {2} - s: {3} {4} - a: {5} - rad: {6} - ({7}, {8})",
                x, y, radio, sentidox, sentidoy, angulo, anguloRad, ancho, alto);
        }
        public void Dibujar(Graphics graphics)
        {
            graphics.FillEllipse(Brushes.Cyan,
                (float)(x - radio),(float)( y - radio),
                2 * radio, 2 * radio);
        }
        public void Borrar(Graphics graphics)
        {
            graphics.FillEllipse(Brushes.White,
                (float)(x - radio), (float)(y - radio),
                2 * radio, 2 * radio);
        }

        public void Mover(int velocidad)
        {
            velo = velocidad;

            //y += 1;
            double desx = velo * sentidox;
            double desy = (velo*sentidoy*Math.Tan(anguloRad));
            
            //x += 1;
            double plx = ancho - radio;
            double ply = alto - radio;

            if ((x < plx)&&sentidox>0)
            {
                x += desx;
                if (x >= plx)
                {
                    x = plx;
                    sentidox *= -1;
                    
                }
            }
            else if ((x < ancho)&&(sentidox < 0))
            {
                x += desx;
                
                if ((x <= radio)&&(sentidox<0))
                {
                    sentidox *= -1;
                }
            }
            

            if ((y < ply)&&(sentidoy>0))
            {
                y += desy;
                if (y >= ply)
                {
                    y = ply;
                    sentidoy *= -1;
                }
            }
            else if ((y < alto)&&(sentidoy<0))
            {
                y += desy;
                if ((y <= radio) && (sentidoy < 0))
                {
                    sentidoy *= -1;
                }
            }
        }

            public bool GetEstado()
        {
            return visible;
        }

        public void CambiaEstado()
        {
            visible = !visible;
        }
    }
}
