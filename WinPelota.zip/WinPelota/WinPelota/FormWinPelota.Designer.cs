﻿
namespace WinPelota
{
    partial class FormWinPelota
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BotonSalir = new System.Windows.Forms.Button();
            this.BotonComenzar = new System.Windows.Forms.Button();
            this.PBCancha = new System.Windows.Forms.PictureBox();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.trackBar = new System.Windows.Forms.TrackBar();
            this.ControladorVelo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PBCancha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // BotonSalir
            // 
            this.BotonSalir.Location = new System.Drawing.Point(878, 415);
            this.BotonSalir.Name = "BotonSalir";
            this.BotonSalir.Size = new System.Drawing.Size(75, 23);
            this.BotonSalir.TabIndex = 0;
            this.BotonSalir.Text = "Salir";
            this.BotonSalir.UseVisualStyleBackColor = true;
            this.BotonSalir.Click += new System.EventHandler(this.BotonSalir_Click);
            // 
            // BotonComenzar
            // 
            this.BotonComenzar.Location = new System.Drawing.Point(782, 415);
            this.BotonComenzar.Name = "BotonComenzar";
            this.BotonComenzar.Size = new System.Drawing.Size(90, 23);
            this.BotonComenzar.TabIndex = 1;
            this.BotonComenzar.Text = "Comenzar";
            this.BotonComenzar.UseVisualStyleBackColor = true;
            this.BotonComenzar.Click += new System.EventHandler(this.BotonComenzar_Click);
            // 
            // PBCancha
            // 
            this.PBCancha.BackColor = System.Drawing.Color.MediumTurquoise;
            this.PBCancha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBCancha.Location = new System.Drawing.Point(12, 12);
            this.PBCancha.Name = "PBCancha";
            this.PBCancha.Size = new System.Drawing.Size(950, 373);
            this.PBCancha.TabIndex = 2;
            this.PBCancha.TabStop = false;
            this.PBCancha.Paint += new System.Windows.Forms.PaintEventHandler(this.PBCancha_Paint);
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Interval = 10;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // trackBar
            // 
            this.trackBar.Location = new System.Drawing.Point(125, 391);
            this.trackBar.Minimum = 1;
            this.trackBar.Name = "trackBar";
            this.trackBar.Size = new System.Drawing.Size(499, 56);
            this.trackBar.TabIndex = 3;
            this.trackBar.Value = 1;
            this.trackBar.Scroll += new System.EventHandler(this.trackBar_Scroll);
            // 
            // ControladorVelo
            // 
            this.ControladorVelo.AutoSize = true;
            this.ControladorVelo.Location = new System.Drawing.Point(33, 403);
            this.ControladorVelo.Name = "ControladorVelo";
            this.ControladorVelo.Size = new System.Drawing.Size(70, 17);
            this.ControladorVelo.TabIndex = 4;
            this.ControladorVelo.Text = "Velocidad";
            // 
            // FormWinPelota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 450);
            this.Controls.Add(this.ControladorVelo);
            this.Controls.Add(this.trackBar);
            this.Controls.Add(this.PBCancha);
            this.Controls.Add(this.BotonComenzar);
            this.Controls.Add(this.BotonSalir);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "FormWinPelota";
            this.Text = "WinPelota";
            ((System.ComponentModel.ISupportInitialize)(this.PBCancha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BotonSalir;
        private System.Windows.Forms.Button BotonComenzar;
        private System.Windows.Forms.PictureBox PBCancha;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.TrackBar trackBar;
        private System.Windows.Forms.Label ControladorVelo;
    }
}

